class TenentInfo {
  int? id;
  String tenentName;
  int nidNo;
  String? passportNo;
  int birthCertificateNo;
  int mobileNo;
  int emgMobileNo;
  int noOfFamilyMem;
  DateTime dateOfIn;

  TenentInfo(
      {this.id,
      required this.tenentName,
      required this.nidNo,
      this.passportNo,
      required this.birthCertificateNo,
      required this.mobileNo,
      required this.emgMobileNo,
      required this.noOfFamilyMem,
      required this.dateOfIn});

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'tenentName': tenentName,
      'nidNo': nidNo,
      'passportNo': passportNo,
      'birthCertificateNo': birthCertificateNo,
      'mobileNo': mobileNo,
      'emgMobileNo': emgMobileNo,
      'noOfFamilyMem': noOfFamilyMem,
      'dateOfIn': dateOfIn
    };
  }

  factory TenentInfo.fromJason(Map<String, dynamic> json) => TenentInfo(
      id: json['id'],
      tenentName: json['tenentName'],
      nidNo: json['nidNo'],
      passportNo: json['passportNo'],
      birthCertificateNo: json['birthCertificateNo'],
      mobileNo: json['mobileNo'],
      emgMobileNo: json['emgMobileNo'],
      noOfFamilyMem: json['noOfFamilyMem'],
      dateOfIn: json['dateOfIn']);
}
