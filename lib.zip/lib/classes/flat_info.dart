class FlatInfo {
  int? id;
  String flatName;
  int noOfMasterbedRoom;
  int noOfBedroom;
  String flatSide;
  double rentAmount;
  int noOfWashroom;
  int flatSize;

  FlatInfo({
    this.id,
    required this.flatName,
    required this.noOfMasterbedRoom,
    required this.noOfBedroom,
    required this.flatSide,
    required this.rentAmount,
    required this.noOfWashroom,
    required this.flatSize,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'flatName': flatName,
      'noOfMasterbedRoom': noOfMasterbedRoom,
      'noOfBedroom': noOfBedroom,
      'flatSide': flatSide,
      'rentAmount': rentAmount,
      'noOfWashroom': noOfWashroom,
      'flatSize': flatSize,
    };
  }

  factory FlatInfo.fromJason(Map<String, dynamic> json) => FlatInfo(
        id: json['id'],
        flatName: json['flatName'],
        noOfMasterbedRoom: json['noOfMasterbedRoom'],
        noOfBedroom: json['noOfBedroom'],
        flatSide: json['flatSide'],
        rentAmount: json['rentAmount'],
        noOfWashroom: json['noOfWashroom'],
        flatSize: json['flatSize'],
      );
}
