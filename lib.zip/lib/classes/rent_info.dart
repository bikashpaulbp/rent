class RentInfo {
  int? id;
  DateTime month;

  double gasBill;
  double waterBill;
  double serviceCharge;
  double? adjustmentAmount;

  RentInfo({
    this.id,
    required this.month,
    required this.gasBill,
    required this.waterBill,
    required this.serviceCharge,
    this.adjustmentAmount,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'month': month,
      'gasBill': gasBill,
      'waterBill': waterBill,
      'serviceCharge': serviceCharge,
      'adjustmentAmount': adjustmentAmount,
    };
  }

  factory RentInfo.fromJason(Map<String, dynamic> json) => RentInfo(
        id: json['id'],
        month: json['month'],
        gasBill: json['gasBill'],
        waterBill: json['waterBill'],
        serviceCharge: json['serviceCharge'],
        adjustmentAmount: json['adjustmentAmount'],
      );
}
