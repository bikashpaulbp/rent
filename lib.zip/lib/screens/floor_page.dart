import 'package:flutter/material.dart';
import 'package:rent_management/screens/dashboard_page.dart';
import 'package:rent_management/screens/test.dart';

import '../classes/floor_info.dart';
import '../db_helper.dart';

class FloorPage extends StatefulWidget {
  const FloorPage({Key? key}) : super(key: key);

  @override
  State<FloorPage> createState() => _FloorPageState();
}

class _FloorPageState extends State<FloorPage> {
  final TextEditingController _floorController = TextEditingController();
  late Stream<List<Floor>> floorStream = Stream.empty();

  @override
  void initState() {
    refresh();
    super.initState();
  }

  refresh() async {
    await DBHelper.initDB();
    floorStream = DBHelper.readFloorData().asStream();
    setState(() {});
  }

  @override
  void dispose() {
    _floorController.dispose();
    super.dispose();
  }

  Future<void> saveFloor() async {
    String floorName = _floorController.text.trim();
    if (floorName.isNotEmpty) {
      Floor floor = Floor(floorName: floorName);
      await DBHelper.insertFloorData(floor);
      _floorController.clear();
      await refresh();
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 125, 125, 125),
        leading: IconButton(
          icon: const Icon(Icons.arrow_circle_left_outlined, size: 35),
          onPressed: () {
            Navigator.pop(
              context,
              MaterialPageRoute(builder: (context) => const Dashboard()),
            );
          },
        ),
        title: const Center(child: Text('Add Your Information')),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Column(
                children: [
                  Container(
                    width: 500,
                    height: 160,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 255, 255, 255),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: const Color.fromARGB(255, 180, 180, 180)
                              .withOpacity(0.5),
                          spreadRadius: 5,
                          blurRadius: 7,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Column(
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: const Color.fromARGB(
                                        255, 134, 134, 134),
                                    width: 1.0,
                                  ),
                                ),
                                padding: const EdgeInsets.only(
                                  left: 140.0,
                                  right: 140.0,
                                ),
                                child: const Text(
                                  'Floor',
                                  style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    color: Color.fromARGB(255, 134, 134, 134),
                                    fontStyle: FontStyle.normal,
                                    // Add any other desired text style properties here
                                  ),
                                ),
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const SizedBox(
                                    child: Text(
                                      'Floor',
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Color.fromARGB(255, 78, 78, 78),
                                        fontStyle: FontStyle.normal,
                                        // Add any other desired text style properties here
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 250,
                                    height: 50,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: TextFormField(
                                        controller: _floorController,
                                        decoration: InputDecoration(
                                          border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 3),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Spacer(),
                                    InkWell(
                                      onTap: saveFloor,
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          width: 100,
                                          height: 45,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.only(
                                              topLeft:
                                                  const Radius.circular(25),
                                              bottomLeft:
                                                  const Radius.circular(25),
                                              topRight:
                                                  const Radius.circular(1),
                                              bottomRight:
                                                  const Radius.circular(1),
                                            ),
                                            color: const Color.fromARGB(
                                                255, 138, 138, 138),
                                          ),
                                          child: Container(
                                            width: 110,
                                            height: 50,
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.only(
                                                topLeft:
                                                    const Radius.circular(25),
                                                bottomLeft:
                                                    const Radius.circular(25),
                                                topRight:
                                                    const Radius.circular(1),
                                                bottomRight:
                                                    const Radius.circular(65),
                                              ),
                                              color: const Color.fromARGB(
                                                  255, 101, 99, 99),
                                            ),
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  bottom: -1,
                                                  right: -1,
                                                  child: const Icon(
                                                    Icons.save,
                                                    size: 17,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Positioned(
                                                  child: const Text(
                                                    'Save',
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 16,
                                                    ),
                                                  ),
                                                  left: 35,
                                                  top: 15,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () {
                                        Navigator.pushReplacement(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) =>
                                                const Dashboard(),
                                          ),
                                        );
                                      },
                                      child: Container(
                                        width: 100,
                                        height: 45,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.only(
                                            topLeft: const Radius.circular(25),
                                            bottomLeft:
                                                const Radius.circular(25),
                                            topRight: const Radius.circular(1),
                                            bottomRight:
                                                const Radius.circular(1),
                                          ),
                                          color: const Color.fromARGB(
                                              255, 138, 138, 138),
                                        ),
                                        child: Container(
                                          width: 110,
                                          height: 50,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.only(
                                              topLeft:
                                                  const Radius.circular(25),
                                              bottomLeft:
                                                  const Radius.circular(25),
                                              topRight:
                                                  const Radius.circular(1),
                                              bottomRight:
                                                  const Radius.circular(65),
                                            ),
                                            color: const Color.fromARGB(
                                                255, 101, 99, 99),
                                          ),
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                bottom: -1,
                                                right: -1,
                                                child: const Icon(
                                                  Icons.cancel,
                                                  size: 17,
                                                  color: Colors.white,
                                                ),
                                              ),
                                              Positioned(
                                                child: const Text(
                                                  'Cancel',
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 16,
                                                  ),
                                                ),
                                                left: 25,
                                                top: 15,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Floors',
                    style: TextStyle(
                      fontSize: 16,
                      color: Color.fromARGB(255, 78, 78, 78),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  StreamBuilder<List<Floor>>(
                    stream: floorStream,
                    builder: (BuildContext context,
                        AsyncSnapshot<List<Floor>> snapshot) {
                      if (snapshot.hasData && snapshot.data!.isNotEmpty) {
                        List<Floor> floorList = snapshot.data!;
                        return ListView.builder(
                          shrinkWrap: true,
                          itemCount: floorList.length,
                          itemBuilder: (BuildContext context, int index) {
                            Floor floor = floorList[index];
                            return ListTile(
                              title: Text(floor.floorName ?? ''),
                            );
                          },
                        );
                      } else {
                        return const Text('No floors available.');
                      }
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
