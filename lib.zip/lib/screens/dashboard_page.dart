import 'dart:async';

import 'package:animated_icon_button/animated_icon_button.dart';
import 'package:flutter/material.dart';

import 'floor_page.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  var tapColor = Color.fromARGB(255, 121, 121, 121);
  var tapIconColor = const Color.fromARGB(255, 255, 255, 255);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 125, 125, 125),
        centerTitle: true,
        title: Center(
          child: Text(
            'Dashboard',
            style: TextStyle(fontSize: 20),
          ),
        ),
      ),
      body: Column(
        children: [
          Container(
            height: 100,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      AnimatedIconButton(
                        size: 40,
                        onPressed: () {
                          setState(() {
                            tapColor = Color.fromARGB(255, 255, 255, 255);
                            tapIconColor =
                                const Color.fromARGB(255, 203, 203, 203);
                            Timer(Duration(milliseconds: 500), () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => FloorPage()));
                            });
                          });
                        },
                        duration: const Duration(milliseconds: 500),
                        splashRadius: 30,
                        splashColor: Colors.transparent,
                        icons: const <AnimatedIconItem>[
                          AnimatedIconItem(
                            icon: Icon(Icons.stairs,
                                color: Color.fromARGB(255, 159, 168, 183)),
                          ),
                        ],
                      ),
                      Text(
                        'Floor',
                        style: TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      AnimatedIconButton(
                        size: 40,
                        onPressed: () {
                          setState(() {
                            tapColor = Color.fromARGB(255, 255, 255, 255);
                            tapIconColor =
                                const Color.fromARGB(255, 203, 203, 203);
                          });
                        },
                        duration: const Duration(milliseconds: 500),
                        splashColor: Colors.transparent,
                        splashRadius: 30,
                        icons: const <AnimatedIconItem>[
                          AnimatedIconItem(
                            icon: Icon(Icons.home,
                                color: Color.fromARGB(255, 159, 168, 183)),
                          ),
                        ],
                      ),
                      Text(
                        'Flat',
                        style: TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      AnimatedIconButton(
                        size: 40,
                        onPressed: () {
                          setState(() {
                            tapColor = Color.fromARGB(255, 255, 255, 255);
                            tapIconColor =
                                const Color.fromARGB(255, 203, 203, 203);
                          });
                        },
                        duration: const Duration(milliseconds: 500),
                        splashColor: Colors.transparent,
                        splashRadius: 30,
                        icons: const <AnimatedIconItem>[
                          AnimatedIconItem(
                            icon: Icon(Icons.people_alt,
                                color: Color.fromARGB(255, 159, 168, 183)),
                          ),
                        ],
                      ),
                      Text(
                        'Tenent',
                        style: TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      AnimatedIconButton(
                        size: 40,
                        onPressed: () {
                          setState(() {
                            tapColor = Color.fromARGB(255, 255, 255, 255);
                            tapIconColor =
                                const Color.fromARGB(255, 203, 203, 203);
                          });
                        },
                        duration: const Duration(milliseconds: 500),
                        splashColor: Colors.transparent,
                        splashRadius: 30,
                        icons: const <AnimatedIconItem>[
                          AnimatedIconItem(
                            icon: Icon(Icons.monetization_on,
                                color: Color.fromARGB(255, 159, 168, 183)),
                          ),
                        ],
                      ),
                      Text(
                        'Rent',
                        style: TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Center(
              child: Container(
                decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 230, 230, 230),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: const Color.fromARGB(255, 180, 180, 180)
                            .withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: const Offset(0, 3),
                      ),
                    ]),
                width: 500,
                height: 400,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
