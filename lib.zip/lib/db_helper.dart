import 'package:path/path.dart';
import 'package:rent_management/classes/flat_info.dart';
import 'package:rent_management/classes/rent_info.dart';
import 'package:rent_management/classes/tenent_info.dart';
import 'package:sqflite/sqflite.dart';

import 'classes/floor_info.dart';

class DBHelper {
  static Future<Database> initDB() async {
    var dpPath = await getDatabasesPath();
    String path = join(dpPath, 'rentmanagement.db');
    return await openDatabase(path, version: 1, onCreate: _onCreate);
  }

  static Future _onCreate(Database db, int version) async {
    final sql = '''CREATE TABLE floor (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        floorName TEXT)''';

    // await db.execute('''CREATE TABLE flat (
    //     id INTEGER PRIMARY KEY,
    //     flatName TEXT, noOfMasterbedRoom INTEGER, noOfBedroom INTEGER, flatSide TEXT, rentAmount INTEGER, noOfWashroom INTEGER, flatSize INTEGER
    //     )''');

    // await db.execute('''CREATE TABLE rent (
    //     id INTEGER PRIMARY KEY,
    //     month TEXT, gasBill INTEGER, waterBill INTEGER, serviceCharge INTEGER, adjustmentAmount INTEGER)
    //     ''');
    // await db.execute('''CREATE TABLE tenent (
    //     id INTEGER PRIMARY KEY,
    //     tenentName TEXT, nidNo INTEGER, passportNo TEXT, birthCertificateNo INTEGER, mobileNo INTEGER, emgMobileNo INTEGER, noOfFamilyMem INTEGER, dateOfIn TEXT
    //     )''');

    await db.execute(sql);
  }

  static Future<int> insertFloorData(Floor floor) async {
    Database db = await DBHelper.initDB();
    return await db.insert('floor', floor.toJson());
  }

  // static Future<int> insertFlatData(FlatInfo flat) async {
  //   Database db = await DBHelper.initDB();
  //   return await db.insert('flat', flat.toJson());
  // }

  // static Future<int> insertRentData(RentInfo rent) async {
  //   Database db = await DBHelper.initDB();
  //   return await db.insert('rent', rent.toJson());
  // }

  // static Future<int> insertTenentData(TenentInfo tenent) async {
  //   Database db = await DBHelper.initDB();
  //   return await db.insert('tenent', tenent.toJson());
  // }

  static Future<List<Floor>> readFloorData() async {
    Database db = await DBHelper.initDB();
    var floor = await db.query('floor', orderBy: 'id');
    List<Floor> floorList =
        floor.isEmpty ? floor.map((e) => Floor.fromJson(e)).toList() : [];
    return floorList;
  }

  // static Future<List<FlatInfo>> readFlatData() async {
  //   Database db = await DBHelper.initDB();
  //   var flat = await db.query('flat');
  //   List<FlatInfo> flatList =
  //       flat.isEmpty ? flat.map((e) => FlatInfo.fromJason(e)).toList() : [];
  //   return flatList;
  // }

  // static Future<List<RentInfo>> readRentData() async {
  //   Database db = await DBHelper.initDB();
  //   var rent = await db.query('rent');
  //   List<RentInfo> rentList =
  //       rent.isEmpty ? rent.map((e) => RentInfo.fromJason(e)).toList() : [];
  //   return rentList;
  // }

  // static Future<List<TenentInfo>> readTenentData() async {
  //   Database db = await DBHelper.initDB();
  //   var tenent = await db.query('tenent');
  //   List<TenentInfo> tenentList = tenent.isEmpty
  //       ? tenent.map((e) => TenentInfo.fromJason(e)).toList()
  //       : [];
  //   return tenentList;
// }
}
